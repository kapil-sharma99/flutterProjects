import 'package:LocalWire/pages/savedPosts.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:dynamic_theme/theme_switcher_widgets.dart';

class MenuPage extends StatefulWidget {
  final String language;

  MenuPage(this.language);

  @override
  _MenuPageState createState() => _MenuPageState(this.language);
}

class _MenuPageState extends State<MenuPage> {
  String language;
  bool isDarkMode;
  _MenuPageState(this.language);

  @override
  void initState() {
    setState(() {
      this.language = language;
    }); 
    super.initState();
  }

  Future _askAboutLanguage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    switch (await showDialog(
        context: context,
        builder: (BuildContext context) => SimpleDialog(
        title: Text(
          'Language Preference',
          style: TextStyle(
            color: DynamicTheme.of(context).data.textTheme.subtitle.color
          ),
        ),
        children: <Widget>[
          SimpleDialogOption(
              child: Container(
                  color: prefs.getString('language') == 'English'
                      ? Colors.blue[300]
                      : Colors.white,
                  child: InkWell(
                    child: Text(
                      'English',
                    ),
                    onTap: () async {
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      prefs.setString('language', 'English');
                      Navigator.pop(context, language);
                    },
                  ))),
          SimpleDialogOption(
              child: Container(
            color: prefs.getString('language') == 'ଓଡ଼ିଆ'
                ? Colors.blue
                : Colors.white,
            child: InkWell(
              child: Text(
                'ଓଡ଼ିଆ',
              ),
              onTap: () async {
                SharedPreferences prefs =
                    await SharedPreferences.getInstance();
                prefs.setString('language', 'ଓଡ଼ିଆ');
                Navigator.pop(context, language);
              },
            ),
          )),
        ],
      ))) {
    }
  }

  void changeBrightness() {
    DynamicTheme.of(context).setBrightness(Theme.of(context).brightness == Brightness.dark ? Brightness.light: Brightness.dark);
  }
  
  void changeColor() {
    DynamicTheme.of(context).setThemeData(new ThemeData(
        primaryColor: Theme.of(context).primaryColor == Colors.indigo ? Colors.red: Colors.indigo
    ));
  }

  Future<String> getDefaultLanguage() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String language = preferences.getString('language');
    return language;
  }

  @override
  Widget build(BuildContext context) {
    final double deviceHeight = MediaQuery.of(context).size.height;
    String language = '';
    getDefaultLanguage().then((onValue) {
      if (onValue == null) {
        language = 'Not set';
      } else {
        language = onValue;
      }
    });
    String isDark;
    getDefaultLanguage().then((value) {
      isDark = value;
    });

    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: ListView(
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(5),
                bottomLeft: Radius.circular(5)
              )
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(children: <Widget>[
                  IconButton(
                    icon: Image.asset('assets/back.png', height: deviceHeight * 0.025, width: deviceHeight * 0.025,),
                    onPressed: () {},
                  ),
                  SizedBox(width: 12,),
                  Text('Settings', style: TextStyle(color: DynamicTheme.of(context).data.textTheme.subtitle.color, fontSize: deviceHeight * 0.03),),
                ],),
                InkWell(
                  onTap: () {},
                    child: Container(
                    height: deviceHeight * 0.045,
                    width: deviceHeight * 0.1,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.horizontal(
                        left: const Radius.circular(20),
                        right: const Radius.circular(20)
                      )
                    ),
                    child: Center(
                        child: Text(
                        'SIGNIN'
                      ),
                    )
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

_launchUrlForMail(String toMailId, String subject) async {
  var url = "mailto:$toMailId?subject=$subject";
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw ('Cannot send email.');
  }
}

_launchUrlForBrowser(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw ('Cannot send email.');
  }
}
