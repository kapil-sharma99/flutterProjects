import 'package:LocalWire/pages/specificCategoryPage.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';

class HomePage extends StatefulWidget {
  String url;
  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {

  List<String> languages = ['English', 'ଓଡ଼ିଆ'];
  Map loadingText = {
    'English': 'Fetching fresh news',
    'ଓଡ଼ିଆ': 'ତାଜା ଖବର',
  };

  HomePageState();

  String language;
  String urlEnglish;
  String urlOdia;
  bool isConnected = true;
  bool isLoadingNext = false;
  bool isLoading = false, isLoadingSuccessful = false;
  List list = List();
  ScrollController listScrollController;
  bool isChanged = false;

  @override
  void initState() {
    getDefaults();
    urlEnglish =
        "http://localwire.me/wp-json/wl/v1/posts/?per_page=20&categories=5";
    urlOdia =
        'http://localwire.me/wp-json/wl/v1/posts/?per_page=20&categories=4';

    super.initState();
  }

  void getDefaults() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    setState(() {
      language = sharedPreferences.getString('language') ?? 'ଓଡ଼ିଆ';
    });
    isInternetConnected();
  }

  // Future<void> _fetchPage(int pageno) async {
  //   setState(() {
  //     isLoadingNext = true;
  //   });
  //   isInternetConnected();
  //   final response = await http.get(url + "&page=" + pageno.toString());
  //   if (response.statusCode == 200) {
  //     setState(() {
  //       isLoadingNext = false;
  //       list += (json.decode(response.body) as List).map((data) {
  //         return Post.fromJSON(data);
  //       }).toList();
  //     });
  //   }
  // }

  void isInternetConnected() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        setState(() {
          isConnected = true;
        });
      }
    } on SocketException catch (_) {
      setState(() {
        isConnected = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 9,
      child: SafeArea(
        top: false,
        child: Scaffold(
        backgroundColor: DynamicTheme.of(context).data.backgroundColor,
        appBar: AppBar(
          backgroundColor: DynamicTheme.of(context).data.backgroundColor,
          elevation: 1,
          title: TabBar(
            unselectedLabelColor: Colors.grey,
            labelColor: Colors.blue,
            isScrollable: true,
            tabs: <Widget>[
              Tab(text: language == 'English' ? "HOME" : "ପ୍ରଚ୍ଛଦ"),
              Tab(text: language == 'English' ? "BHUBANESWAR" : "ଭୁବନେଶ୍ୱର"),
              Tab(text: language == 'English' ? "SPECIAL" : "ବିଶେଷ"),
              Tab(text: language == 'English' ? "ENTERTAINMENT" : "ମନୋରଞ୍ଜନ"),
              Tab(text: language == 'English' ? "BUSINESS" : "ବ୍ୟବସାୟ"),
              Tab(text: language == 'English' ? "POLITICS" : "ରାଜନୀତି"),
              Tab(text: language == 'English' ? "SPORTS" : "ଖେଳ"),
              Tab(text: language == 'English' ? "HEALTH" : "ସ୍ୱାସ୍ଥ୍ୟ"),
              Tab(text: language == 'English' ? "EDUCATION" : "ଶିକ୍ଷା"),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            SpecificCategoryPage(
              true,
              this,
              language,
              name: 'home',
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'bhubaneswar'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'special'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'entertainment'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'business'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'politics'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'sports'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'health'
            ),
            SpecificCategoryPage(
              false,
              this,
              language,
              name: 'education'
            ),
          ],
        ),
      ),
      )
    );
  }
}